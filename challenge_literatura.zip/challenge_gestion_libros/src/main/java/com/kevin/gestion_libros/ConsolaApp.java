package com.kevin.gestion_libros;

import com.kevin.gestion_libros.api.GutendexClient;
import com.kevin.gestion_libros.entity.Libro;
import com.kevin.gestion_libros.service.LibroService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

@Component
public class ConsolaApp implements CommandLineRunner {

    private final GutendexClient gutendexClient;
    private final LibroService libroService;

    public ConsolaApp(GutendexClient gutendexClient, LibroService libroService) {
        this.gutendexClient = gutendexClient;
        this.libroService = libroService;
    }

    @Override
    @SuppressWarnings("resource") // evitamos warning por Scanner(System.in)
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        System.out.println("Bienvenido al sistema de gestión de libros Gutendex");

        while (!salir) {
            // Mostrar menú
            System.out.println("\nElija la opción a través de su número:");
            System.out.println("1- Buscar libro por título");
            System.out.println("2- Buscar libros registrados");
            System.out.println("3- Listar autores registrados");
            System.out.println("4- Autores vivos en un determinado año (no implementado)");
            System.out.println("5- Listar libros por idioma");
            System.out.println("0- Salir");
            System.out.print("Opción: ");

            String opcion = scanner.nextLine().trim();

            switch (opcion) {
                case "1":
    System.out.print("Ingrese el título del libro que desea buscar: ");
    String titulo = scanner.nextLine().trim();
    try {
        System.out.println("Buscando libros... por favor espere."); // <- mensaje de espera
        List<Libro> libros = gutendexClient.buscarLibros(titulo);
        if (libros.isEmpty()) {
            System.out.println("No se encontraron libros con ese título.");
        } else {
            libros.forEach(libroService::guardar); // Guardar en BD
            libros.forEach(this::mostrarLibro);
        }
    } catch (IOException e) {
        System.out.println("Error al buscar libros: " + e.getMessage());
    }
    break;


                case "2":
                    List<Libro> todos = libroService.listarTodos();
                    if (todos.isEmpty()) {
                        System.out.println("No hay libros registrados.");
                    } else {
                        todos.forEach(this::mostrarLibro);
                    }
                    break;

                case "3":
                    List<Libro> librosAutores = libroService.listarTodos();
                    if (librosAutores.isEmpty()) {
                        System.out.println("No hay autores registrados.");
                    } else {
                        System.out.println("Autores registrados:");
                        librosAutores.stream()
                                     .map(Libro::getAutor)
                                     .distinct()
                                     .forEach(a -> System.out.println("- " + a));
                    }
                    break;

                case "4":
                    System.out.println("Función no implementada aún.");
                    break;

                case "5":
                    System.out.print("Ingrese el idioma (ej: en, es, fr): ");
                    String idioma = scanner.nextLine().trim();
                    List<Libro> librosIdioma = libroService.listarPorIdioma(idioma);
                    if (librosIdioma.isEmpty()) {
                        System.out.println("No se encontraron libros en ese idioma.");
                    } else {
                        librosIdioma.forEach(this::mostrarLibro);
                    }
                    break;

                case "0":
                    System.out.println("Saliendo del sistema...");
                    salir = true;
                    break;

                default:
                    System.out.println("Opción inválida, intente de nuevo.");
            }

            System.out.println("\nTotal libros guardados en BD: " + libroService.listarTodos().size());
        }
    }

    private void mostrarLibro(Libro libro) {
        System.out.println("-----------------------------------");
        System.out.println("----- LIBRO -----");
        System.out.println("Título: " + libro.getTitulo());
        System.out.println("Autor: " + libro.getAutor());
        System.out.println("Idioma: " + libro.getIdioma());
        System.out.println("Número de descargas: " + libro.getNumDescargas());
        System.out.println("-----------------------------------");
    }
}
