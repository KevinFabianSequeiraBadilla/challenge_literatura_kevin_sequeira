package com.kevin.gestion_libros.api;

import com.kevin.gestion_libros.entity.Libro;
import com.kevin.gestion_libros.service.LibroService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@RestController
public class LibroController {

    private final GutendexClient gutendexClient;
    private final LibroService libroService;

    public LibroController(GutendexClient gutendexClient, LibroService libroService) {
        this.gutendexClient = gutendexClient;
        this.libroService = libroService;
    }

    // Buscar libros desde la API externa
    @GetMapping("/buscar")
    public List<Libro> buscar(@RequestParam String titulo) throws IOException {
        List<Libro> libros = gutendexClient.buscarLibros(titulo);
        // Guardar resultados en la BD
        libros.forEach(libroService::guardar);
        return libros;
    }

    // Listar todos los libros guardados
    @GetMapping("/libros")
    public List<Libro> listar() {
        return libroService.listarTodos();
    }
}
