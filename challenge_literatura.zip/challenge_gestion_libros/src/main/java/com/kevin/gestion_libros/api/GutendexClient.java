package com.kevin.gestion_libros.api;

import com.kevin.gestion_libros.entity.Libro;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@Component
public class GutendexClient {

    private final String API_BASE = "https://gutendex.com/books?search=";

    public List<Libro> buscarLibros(String titulo) throws IOException {
        List<Libro> libros = new ArrayList<>();
        URL url = new URL(API_BASE + titulo.replace(" ", "%20"));
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // Configurar timeout (10 segundos)
        conn.setConnectTimeout(10000); // conexión
        conn.setReadTimeout(10000);    // lectura

        conn.setRequestMethod("GET");

        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new RuntimeException("Error al conectarse a la API: " + responseCode);
        }

        // Leer respuesta de forma segura
        StringBuilder inline = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                inline.append(line);
            }
        }

        JSONObject json = new JSONObject(inline.toString());
        JSONArray results = json.getJSONArray("results");

        for (int i = 0; i < results.length(); i++) {
            JSONObject item = results.getJSONObject(i);
            String bookTitle = item.getString("title");
            String idioma = item.getJSONArray("languages").length() > 0
                    ? item.getJSONArray("languages").getString(0)
                    : "Desconocido";
            String autor = item.getJSONArray("authors").length() > 0
                    ? item.getJSONArray("authors").getJSONObject(0).getString("name")
                    : "Desconocido";
            Integer downloads = item.has("download_count") ? item.getInt("download_count") : 0;

            libros.add(new Libro(bookTitle, autor, idioma, downloads));
        }

        return libros;
    }
}
